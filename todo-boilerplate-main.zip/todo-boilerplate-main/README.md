# todo-boilerplate

Todo boilerplate for React.

---

## Cloning the repository

Now clone this repository to your own device. Click the Clone or download button and click the Copy to Clipboard icon.

Open a terminal and run the following Git command:

    $ git clone https://github.com/dasom222g/todo-boilerplate.git

Getting start

    $ yarn or yarn install

## Start working

    $ yarn start
